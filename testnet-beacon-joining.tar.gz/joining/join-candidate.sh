#!/bin/bash
. vars.env

# e.g. 100000 here represent 100,000 alt
STAKING_AMOUNT=100000

NODE_PORT=9944

docker pull public.ecr.aws/z6d8z0h2/altctl:latest

printf "Generating session key\n"
docker run \
  --rm \
  --network altlayer \
  --name altctl \
  --env NODE_PORT=$NODE_PORT \
  --env-file vars.env \
  --entrypoint=bash \
  --volume ./:/data \
  --workdir /data \
  public.ecr.aws/z6d8z0h2/altctl:latest \
  -c 'altctl author rotate-keys --endpoint ws://alt-beacon-validator:$NODE_PORT > session_key.txt'

printf "Submitting extrinsic session::setKeys\n"
docker run \
  --rm \
  --network altlayer \
  --name altctl \
  --env NODE_PORT=$NODE_PORT \
  --env-file vars.env \
  --entrypoint=bash \
  --volume ./:/data \
  --workdir /data \
  public.ecr.aws/z6d8z0h2/altctl:latest \
  -c 'altctl session set-keys --endpoint ws://alt-beacon-validator:$NODE_PORT \
  --keys=$(head -n 1 session_key.txt) \
  --proof=0x \
  --seed="$MNEMONIC"'

printf "Submitting extrinsic altBeaconStaking::joinCanditates\n"
docker run \
  --rm \
  --network altlayer \
  --name altctl \
  --env NODE_PORT=$NODE_PORT \
  --env STAKING_AMOUNT=$STAKING_AMOUNT \
  --env-file vars.env \
  --entrypoint=bash \
  --volume ./:/data \
  --workdir /data \
  public.ecr.aws/z6d8z0h2/altctl:latest \
  -c 'altctl join-candidate --endpoint ws://alt-beacon-validator:$NODE_PORT \
  --bound="$STAKING_AMOUNT" \
  --seed="$MNEMONIC"'
