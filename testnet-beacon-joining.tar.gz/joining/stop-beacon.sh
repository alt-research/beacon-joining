#!/bin/bash
docker stop alt-beacon-validator
docker container rm alt-beacon-validator
docker network rm altlayer
docker image rm public.ecr.aws/z6d8z0h2/altctl:latest -f