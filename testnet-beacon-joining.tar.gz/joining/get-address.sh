#!/bin/bash
NODE_PORT=9944

docker pull public.ecr.aws/z6d8z0h2/altctl:latest

printf "Getting account information from MNEMONIC. Please use Index 0\n"
docker run \
  --rm \
  --network altlayer \
  --name altctl \
  --env-file vars.env \
  --entrypoint=bash \
  public.ecr.aws/z6d8z0h2/altctl:latest \
  -c 'altctl key generate \
  -m "$MNEMONIC"'
