#!/bin/bash
docker network create \
    --attachable \
    altlayer

docker run \
    --detach \
    --restart unless-stopped \
    --name alt-beacon-validator \
    --entrypoint bash \
    --env-file vars.env \
    --env RUSTLOG='runtime=info' \
    --publish 30333:30333 \
    --publish 9933:9933 \
    --publish 9944:9944 \
    --publish 9615:9615 \
    --user root \
    --volume data:/data \
    --volume ./chainspec.json:/chainspec.json \
    --volume ./keystore:/data/chains/altbeacon_testnet/keystore \
    --workdir /data \
    305587085711.dkr.ecr.us-west-2.amazonaws.com/alt-beacon:tracing-f604c21 \
    -c '/usr/local/bin/alt-beacon key insert \
        --base-path=/data \
        --key-type aura \
        --scheme Sr25519 \
        --chain=/chainspec.json \
        --suri="$MNEMONIC//aura"; \
        /usr/local/bin/alt-beacon key insert \
        --base-path=/data \
        --key-type gran \
        --scheme Ed25519 \
        --chain=/chainspec.json \
        --suri="$MNEMONIC//grandpa"; \
        chmod -R 0755 /data/chains/*/keystore; \
        exec /usr/local/bin/alt-beacon \
        --validator \
        --log=info \
        --base-path=/data \
        --chain=/chainspec.json \
        --port=30333 \
        --rpc-port=9933 \
        --ws-port=9944 \
        --prometheus-port=9615 \
        --rpc-cors=all \
        --rpc-methods=unsafe \
        --unsafe-rpc-external \
        --unsafe-ws-external \
        --prometheus-external \
        --execution=native-else-wasm \
        --node-key=$NODEKEY'
    