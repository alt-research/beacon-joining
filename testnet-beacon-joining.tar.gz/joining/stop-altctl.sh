#!/bin/bash
docker stop altctl