#!/bin/bash
NODE_PORT=9944

docker pull public.ecr.aws/z6d8z0h2/altctl:latest

printf "Submitting extrinsic altBeaconStaking::scheduleLeaveCandidates\n"
docker run \
  --rm \
  --network altlayer \
  --name altctl \
  --env NODE_PORT=$NODE_PORT \
  --env-file vars.env \
  --entrypoint=bash \
  --volume ./:/data \
  --workdir /data \
  public.ecr.aws/z6d8z0h2/altctl:latest \
  -c 'altctl schedule-leave-candidates \
  --endpoint ws://alt-beacon-validator:$NODE_PORT \
  --seed="$MNEMONIC"'
